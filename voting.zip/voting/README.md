# voting

A Pen created on CodePen.

Original URL: [https://codepen.io/kirti_jindal/pen/QwjLdmE](https://codepen.io/kirti_jindal/pen/QwjLdmE).

